# Yaseen Baloch — Personal Brand Landing Page

Oasis Infobyte Internship · Web Development & Designing · Level 1

## Tech Stack
- HTML5
- CSS3
- Flexbox and CSS Grid
- Google Fonts

## Features
- Sticky navigation with at least three links
- Hero section with headline, subheadline and calls to action
- About, skills, projects and community sections
- Contact footer with email, WhatsApp and social links\n- Four project cards with completed and in-progress statuses
- Responsive desktop and mobile layouts
- CSS-only mobile navigation
- Consistent Dark Navy and Emerald visual theme
- Hover states and accessible reduced-motion handling

## Run
Open `index.html` in a modern browser. No build tools or JavaScript are required.

## Structure
```text
WebDev-L1-LandingPage/
├── index.html
├── style.css
├── assets/
│   └── profile.jpg
└── README.md
```

Project statuses and skill descriptions are intentionally conservative: ongoing learning is not represented as completed professional experience.
